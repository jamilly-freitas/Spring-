package br.spring.DW2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dw2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
